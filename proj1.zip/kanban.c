/*
 * File: kanban.c
 *
 * Author: Luís Cunha dos Reis Infante da Câmara (ist199099)
 * E-mail: luis.infante.da.camara@tecnico.ulisboa.pt
 *
 * Description:
 * The goal of this project is the development of
 * a Kanban-type task management system in the C programming language.
 * This is the main implementation file for this project.
 *
 * This is project 1 for subject IAED1011132646
 * (Introduction to Algorithms and to Data Structures)
 * of course LEIC-T:
 * <https://fenix.tecnico.ulisboa.pt/disciplinas/IAED1011132646/2020-2021/2-semestre>.
 *
 * Links to useful information (in Portuguese) about the project:
 * Statement:  https://github.com/pedroreissantos/iaed21/blob/main/p1/README.md
 * Guidelines: https://github.com/pedroreissantos/iaed21/blob/main/p1/guidelines.md
 * FAQ:        https://github.com/diogotcorreia/kanban-iaed-tests/blob/master/FAQ.md
 *             (maintained by the delegate of year 1 of degree LEIC-A)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kanban_messages.h"

/* Each task is identified by an integer between 1 and TASK_MAX. */
#define TASK_MAX 10000
/* A value of type unsigned short has a range of 0 to (at least) 65535.
 * Therefore, it can store any task identifier,
 * as well as the sentinel value 0 (to denote the absence of a task).
 */
typedef unsigned short task_type;
/* Conversion that is to be used with printf
 * to write a value of type task_type.
 *
 * The statement of the project mandates the use of signed types
 * for the reading of decimal integers.
 * Therefore, format %d is such for all such input.
 */
#define TASK_ID_FORMAT "%hu"

/* Maximum size (in bytes) of the description of a task. */
#define TASK_DESCRIPTION_MAX 50
/* Conversion that is to be used with scanf() to read the description of a task. */
#define TASK_DESCRIPTION_FORMAT "%50[^\n]"

struct task;

/* Maximum size (in bytes) of the description of an activity. */
#define ACTIVITY_DESCRIPTION_MAX 20
/* Maximum number of activities supported by the system. */
#define ACTIVITY_MAX 10
/* Conversion that is to be used with scanf() to read the description of an activity. */
#define ACTIVITY_FORMAT "%20[^\n]"
/* List of characters that are not allowed
 * in the description of any activity.
 */
#define ACTIVITY_DESCRIPTION_BLACKLIST "abcdefghijklmnopqrstuvwxyz"

struct activity {
	char description[ACTIVITY_DESCRIPTION_MAX + 1];
};

/* A value of type unsigned char has a range of 0 to (at least) 255.
 * Therefore, it can store any activity identifier (from 0 to ACTIVITY_MAX - 1 = 9),
 * as well as the sentinel value ACTIVITY_MAX (to denote the absence of an activity).
 */
typedef unsigned char activity_type;

/* Maximum size (in bytes) of the name of a user. */
#define USER_NAME_MAX 20
/* Maximum number of users supported by the system. */
#define USER_MAX 50
/* Conversion that is to be used with scanf() to read the name of a user. */
#define USER_NAME_FORMAT "%20s"

struct user {
	char name[USER_NAME_MAX + 1];
};

/* A value of type unsigned char has a range of 0 to (at least) 255.
 * Therefore, it can store any activity identifier (from 0 to USER_MAX - 1 = 19),
 * as well as the sentinel value ACTIVITY_MAX (to denote the absence of an activity).
 */
typedef unsigned char user_type;

struct task {
	task_type identifier;
	char description[TASK_DESCRIPTION_MAX + 1];
	user_type user;
	activity_type activity;
	unsigned int estimated_duration;
	unsigned int start_time;
};

/* The current time of the Kanban system.
 * This is unrelated to the date and time made available by the operating system.
 */
unsigned int time = 0;
/* The number of tasks currently being stored in the system. */
task_type task_count = 0;
/* The number of activities currently being stored in the system. */
activity_type activity_count = 3;
/* The number of users currently being recorded in the system. */
user_type user_count = 0;

/* Array of structures that represent each task of the system, in order of creation. */
struct task tasks[TASK_MAX];
/* Array of structures that represent each activity of the system, in order of creation. */
struct activity activities[ACTIVITY_MAX] = {
	{ACTIVITY_STRING_TODO},
	{ACTIVITY_STRING_IN_PROGRESS},
	{ACTIVITY_STRING_DONE}
};

/* Array of structures that represent each user of the system, in order of creation. */
struct user users[USER_MAX];

/* Index of the activity TO DO. */
#define ACTIVITY_TODO 0
/* Index of the activity DONE. */
#define ACTIVITY_DONE 2

/* Format to be used with scanf() to scan the arguments of the command 't'. */
#define ARGS_FORMAT_T " %d %50[^\n]"
/* Format to be used with scanf() to scan one argument of the command 'l'. */
#define ARG_FORMAT_L  " %d"
/* Format to be used with scanf() to scan the arguments of the command 'n'. */
#define ARGS_FORMAT_N " %d"
/* Format to be used with scanf() to scan the optional argument of the command 'u'. */
#define ARGS_FORMAT_U " %20s"
/* Format to be used with scanf() to scan the arguments of the command 'm'. */
#define ARGS_FORMAT_M " %d %20s %20[^\n]"
/* Format to be used with scanf() to scan the arguments of the command 'd'. */
#define ARGS_FORMAT_D " %20[^\n]"
/* Format to be used with scanf() to scan the optional argument of the command 'a'. */
#define ARGS_FORMAT_A " %20[^\n]"

typedef int (*task_comparison_function) (struct task * a, struct task * b);

/* Temporary vector that stores the result of the last sorting of the tasks. */
struct task sorted_tasks[TASK_MAX];

/* Consumes all initial spaces and returns the next character after those spaces
 * in the standard input, without consuming the latter.
 * This procedure does not handle EOF.
 */
char
peek_nonspace() {
	char c;

	while ((c = getchar()) == ' ');
	ungetc(c, stdin);
	return c;
}

/* Compares tasks a and b by their names. */
int
compare_tasks_l(struct task *a, struct task *b) {
	return strcmp(a->description, b->description);
}

/* Compares tasks a and b by their start time
 * and, if a and b have the same start time, by their names.
 */
int
compare_tasks_d(struct task *a, struct task *b) {
	if (a->start_time < b->start_time)
		return -1;
	if (a->start_time > b->start_time)
		return 1;
	return compare_tasks_l(a, b);
}

/* Hoare partition scheme, that is an implementation of a partitioning function
 * that results in an efficient quick sort, when compared with other partitioning schemes.
 * In addition, the performance of this algorithm is generally O(n log n),
 * including for already sorted data (in this case, tasks).
 * The function f is used as the comparison function.
 *
 * This algorithm is sourced from
 * <https://en.wikipedia.org/wiki/Quicksort#Hoare_partition_scheme>.
 */
unsigned int
partition_tasks(struct task a[], unsigned int lo, unsigned int hi, task_comparison_function f) {
	/* If this is passed by reference, the algorithm will not work. */
	struct task pivot = a[(lo + hi) >> 1];
	unsigned int i = lo - 1, j = hi + 1;
	struct task temp;

	while (1) {
		do {
			i += 1;
		} while (f(&a[i], &pivot) < 0);
		do {
			j -= 1;
		} while (f(&a[j], &pivot) > 0);

		if (i >= j)
			return j;
		temp = a[i];
		a[i] = a[j];
		a[j] = temp;
	}
}

/* Sorts the tasks in indices i through j of the array a (a[i..j]), using quicksort.
 * The function f is used to compare tasks.
 */
void
sort_tasks_aux(struct task a[], unsigned int i, unsigned int j, task_comparison_function f) {
	unsigned int p;

	if (i < j) {
		p = partition_tasks(a, i, j, f);
		sort_tasks_aux(a, i, p, f);
		sort_tasks_aux(a, p + 1, j, f);
	}
}

/* Sorts the tasks in the array tasks, that has count elements.
 * The function f is used to compare tasks.
 */
void
sort_tasks(struct task tasks[], struct task *sorted_tasks, unsigned int count,
		   task_comparison_function f) {
	memcpy(sorted_tasks, tasks, count * sizeof(struct task));
	if (count > 1) {
		sort_tasks_aux(sorted_tasks, 0, count - 1, f);
	}
}

/* Adds a new task to the Kanban system. */
void
new_task(unsigned int duration, const char description[TASK_DESCRIPTION_MAX + 1]) {
	task_type i;

	i = task_count;
	task_count += 1;
	tasks[i].identifier = task_count;
	strcpy(tasks[i].description, description);
	tasks[i].user = 0;
	tasks[i].activity = ACTIVITY_TODO;
	tasks[i].estimated_duration = duration;
	tasks[i].start_time = 0;
	printf(NEW_TASK, tasks[i].identifier);
}

/* Implements the 't' command, that adds a new task to the Kanban system. */
void
cmd_t() {
	int duration;
	char task_desc[TASK_DESCRIPTION_MAX + 1];
	task_type i;

	scanf(ARGS_FORMAT_T, &duration, task_desc);

	if (task_count == TASK_MAX) {
		puts(TOO_MANY_TASKS);
		return;
	}
	for (i = 1; i <= task_count; i += 1) {
		if (!strcmp(task_desc, tasks[i - 1].description)) {
			puts(DUPLICATE_DESCRIPTION);
			return;
		}
	}
	if (duration <= 0) {
		puts(INVALID_DURATION);
		return;
	}

	new_task((unsigned int) duration, task_desc);
}

/* Prints the task tasks[i]. */
void
print_task_at(struct task tasks[], unsigned int i) {
	printf(TASK_FORMAT,
		   tasks[i].identifier, activities[tasks[i].activity].description,
		   tasks[i].estimated_duration, tasks[i].description);
}

/* If id is a valid task identifier,
 * prints the task with the identifier id and returns 1.
 * Otherwise, prints nothing and returns 0.
 */
int
print_task(task_type id) {
	if (id == 0 || id > task_count) {
		return 0;
	}
	print_task_at(tasks, id - 1);
	return 1;
}

/* Implements the 't' command, that prints a sorted list of all tasks
 * or a list of certain tasks, in the order of reference in the arguments.
 */
void
cmd_l() {
	int id;
	unsigned int i;

	id = 0;
	if (peek_nonspace() == '\n') {
		sort_tasks(tasks, sorted_tasks, task_count, compare_tasks_l);

		for (i = 0; i < task_count; i += 1) {
			print_task_at(sorted_tasks, i);
		}
		return;
	}
	scanf(ARG_FORMAT_L, &id);
	do {
		if (!print_task((task_type) id)) {
			printf(NO_SUCH_TASK_1, id);
			return;
		}
	} while (scanf(ARG_FORMAT_L, &id) == 1);
}

/* Implements the 'n' command, that increases the time of the system.
 * An increase of 0 is supported and allows the current time to be obtained
 * without changing it.
 */
void
cmd_n() {
	int duration;

	scanf(ARGS_FORMAT_N, &duration);
	if (duration < 0) {
		puts(INVALID_TIME_SPAN);
		return;
	}
	time += duration;
	printf(NEW_TIME_FORMAT, time);
}

/* Prints a list of all users of the system, in order of creation. */
void
list_users() {
	unsigned int i;

	for (i = 0; i < user_count; i += 1) {
		puts(users[i].name);
	}
}

/* Returns the index of the user with the name name,
 * or USER_MAX if there is no such user.
 */
user_type
find_user(char *name) {
	user_type i;

	for (i = 0; i < user_count; i += 1) {
		if (strcmp(users[i].name, name) == 0) {
			return i;
		}
	}
	return USER_MAX;
}

/* Implements the 'u' command, that either adds a new user to the system,
 * or prints a list of all users.
 */
void
cmd_u() {
	char user_name[USER_NAME_MAX + 1];

	if (peek_nonspace() == '\n') {
		list_users();
		return;
	}
	scanf(ARGS_FORMAT_U, user_name);

	if (user_count == USER_MAX) {
		puts(TOO_MANY_USERS);
		return;
	}
	if (find_user(user_name) != USER_MAX) {
		puts(USER_ALREADY_EXISTS);
		return;
	}

	strcpy(users[user_count].name, user_name);
	user_count += 1;
}

/* Prints a list of the activities, in order of creation. */
void
list_activities() {
	unsigned int i;

	for (i = 0; i < activity_count; i += 1) {
		puts(activities[i].description);
	}
}

/* Returns the index of the activity with the description desc,
 * or ACTIVITY_MAX if there is no such activity.
 */
activity_type
find_activity(char *desc) {
	activity_type i;

	for (i = 0; i < activity_count; i += 1) {
		if (strcmp(activities[i].description, desc) == 0) {
			return i;
		}
	}
	return ACTIVITY_MAX;
}

/* Auxiliary function for the 'm' command. */
void
move_task_aux(struct task *t, user_type user, activity_type activity) {
	t->user = user;
	if (t->activity == activity)
		return;
	if (t->activity == ACTIVITY_TODO)
		t->start_time = time;
	t->activity = activity;
	if (activity == ACTIVITY_DONE) {
		unsigned int duration = time - t->start_time;
		printf(DURATION_SLACK, duration, (int) duration - (int) t->estimated_duration);
	}
}

/* Implements the 'm' command, that moves a task from one activity to another.
 * If the task is moved from activity TO DO, its start time is set.
 * If the task is moved to activity DONE, a message is printed
 * indicating the actual duration of the task
 * and the difference (slack=) between that duration and the estimated duration
 * (a positive value for this difference means that the task took longer than estimated).
 */
void
cmd_m() {
	int scanned_id;
	char user_name[20];
	char activity_desc[20];
	user_type user;
	activity_type activity;
	struct task *t;

	scanf(ARGS_FORMAT_M, &scanned_id, user_name, activity_desc);
	if (scanned_id < 1 || scanned_id > task_count) {
		puts(NO_SUCH_TASK);
		return;
	}
	t = &tasks[scanned_id - 1];
	if (t->activity != ACTIVITY_TODO && strcmp(activity_desc, ACTIVITY_STRING_TODO) == 0) {
		puts(TASK_ALREADY_STARTED);
		return;
	}
	user = find_user(user_name);
	if (user == USER_MAX) {
		puts(NO_SUCH_USER);
		return;
	}
	activity = find_activity(activity_desc);
	if (activity == ACTIVITY_MAX) {
		puts(NO_SUCH_ACTIVITY);
		return;
	}
	move_task_aux(t, user, activity);
}

/* Implements the 'd' command, that prints a sorted list of the tasks
 * that are in a given activity.
 */
void
cmd_d() {
	/* Temporary vector that stores the structures that are in the given activity. */
	static struct task found_tasks[TASK_MAX];
	char activity_name[ACTIVITY_DESCRIPTION_MAX + 1];
	unsigned int list_size;
	activity_type activity;
	task_type i;

	scanf(ARGS_FORMAT_D, activity_name);
	activity = find_activity(activity_name);
	if (activity == ACTIVITY_MAX) {
		puts(NO_SUCH_ACTIVITY);
		return;
	}

	list_size = 0;
	for (i = 0; i < task_count; i += 1) {
		if (tasks[i].activity == activity) {
			memcpy(&found_tasks[list_size], &tasks[i], sizeof(struct task));
			list_size += 1;
		}
	}
	sort_tasks(found_tasks, sorted_tasks, list_size, compare_tasks_d);
	for (i = 0; i < list_size; i += 1) {
		struct task *t = &sorted_tasks[i];
		printf(TASK_FORMAT_D, t->identifier, t->start_time, t->description);
	}
}

/* Implements the 'a' command, that either adds a new activity to the system,
 * or lists all activities in the system.
 */
void
cmd_a() {
	char activity_desc[ACTIVITY_DESCRIPTION_MAX + 1];

	if (peek_nonspace() == '\n') {
		list_activities();
		return;
	}
	scanf(ARGS_FORMAT_A, activity_desc);

	if (strcspn(activity_desc, ACTIVITY_DESCRIPTION_BLACKLIST) != strlen(activity_desc)) {
		puts(INVALID_DESCRIPTION);
		return;
	}
	if (activity_count == ACTIVITY_MAX) {
		puts(TOO_MANY_ACTIVITIES);
		return;
	}
	if (find_activity(activity_desc) != ACTIVITY_MAX) {
		puts(DUPLICATE_ACTIVITY);
		return;
	}

	strcpy(activities[activity_count].description, activity_desc);
	activity_count += 1;
}

int
main() {
	while (1) {
		int c = getchar();
		switch (c) {
		case 'q':
			return 0;
		case 't':
			cmd_t();
			break;
		case 'l':
			cmd_l();
			break;
		case 'n':
			cmd_n();
			break;
		case 'u':
			cmd_u();
			break;
		case 'm':
			cmd_m();
			break;
		case 'd':
			cmd_d();
			break;
		case 'a':
			cmd_a();
			break;
		}
		/* To read the next command in the beginning of the next iteration,
		 * it is necessary to consume the spaces at the end of the input line
		 * and the newline character that were left by the cmd_*() functions
		 * (that implement the commands).
		 */
		c = peek_nonspace();
		if (c == '\n') {
			getchar();
		}
	}
}
