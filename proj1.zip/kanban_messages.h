/*
 * File: kanban_messages.h
 *
 * Author: Luís Cunha dos Reis Infante da Câmara (ist199099)
 * E-mail: luis.infante.da.camara@tecnico.ulisboa.pt
 *
 * Description:
 * The goal of this project is the development of
 * a Kanban-type task management system in the C programming language.
 * This file provides translatable messages, formats for messages
 * and other strings for the project.
 * Note that a production application would normally use a portable translation library,
 * such as GNU gettext, and store the translations in separate files.
 *
 * This is project 1 for subject IAED1011132646
 * (Introduction to Algorithms and to Data Structures)
 * of course LEIC-T:
 * <https://fenix.tecnico.ulisboa.pt/disciplinas/IAED1011132646/2020-2021/2-semestre>.
 *
 * Links to useful information (in Portuguese) about the project:
 * Statement:  https://github.com/pedroreissantos/iaed21/blob/main/p1/README.md
 * Guidelines: https://github.com/pedroreissantos/iaed21/blob/main/p1/guidelines.md
 * FAQ:        https://github.com/diogotcorreia/kanban-iaed-tests/blob/master/FAQ.md
 *             (maintained by the delegate of year 1 of degree LEIC-A)
 */

#ifndef KANBAN_MESSAGES_H
#define KANBAN_MESSAGES_H

/* Message that is printed when a task with a given identifier does not exist. */
#define NO_SUCH_TASK "no such task"
/* Format for the message that is printed in place of NO_SUCH_TASK when a request of
 * a type that allows it to contain several task identifiers is processed and,
 * in that processing, a task identifier is encountered
 * that is not the identifier of any task in the system.
 * This format takes one argument:
 * the task identifier that caused the error, as a value of type task_type.
 */
#define NO_SUCH_TASK_1 "%hu: no such task\n"
/* Message that is printed when an activity with a given description does not exist. */
#define NO_SUCH_ACTIVITY "no such activity"
/* Message that is printed when a user with a given description does not exist. */
#define NO_SUCH_USER "no such user"

/* Format for the message that is printed when a new task is created.
 * This format takes one argument:
 * the identifier of the new task, as a value of type task_type.
 */
#define NEW_TASK "task %hu\n"
/* Format for the message that is printed by the 'n' command when it is correctly invoked.
 * This format takes one argument:
 * the new time of the Kanban system, as a value of type unsigned int.
 */
#define NEW_TIME_FORMAT "%u\n"
/* Format for the message that is printed when a task is moved
 * from an activity that is not DONE to the activity DONE.
 * This format takes two arguments:
 * the actual duration of the task, as a value of type unsigned int,
 * and the difference (slack) between that duration and the estimated duration of the task,
 * as a value of type int.
 */
#define DURATION_SLACK "duration=%u slack=%d\n"
/* Display format for a task. This format takes 4 arguments:
 *   0. The identifier of a task, as a value of type task_type.
 *   1. The activity of the task, as a value of type char*.
 *   2. The estimated duration of the task, as a value of type unsigned int.
 *   3. The description of a task, as a value of type char*.
 */
#define TASK_FORMAT "%hu %s #%u %s\n"
/* Display format for a task, used in the 'd' command.
 * This format differs from TASK_FORMAT in that the activity is not included.
 * Therefore, this format takes 3 arguments, in the same order as those of TASK_FORMAT.
 */
#define TASK_FORMAT_D "%hu %u %s\n"
/* Message that is printed when the maximum number of tasks
 * in the system would be exceeded by an operation requested by the client
 * (currently this can only be caused by a task creation request).
 */
#define TOO_MANY_TASKS "too many tasks"
/* Message that is printed when the maximum number of activities
 * in the system would be exceeded by an operation requested by the client
 * (currently this can only be caused by an activity creation request).
 */
#define TOO_MANY_ACTIVITIES "too many activities"
/* Message that is printed when the maximum number of users recorded
 * in the system would be exceeded by an operation requested by the client.
 */
#define TOO_MANY_USERS "too many users"
/* Message that is printed when there is already a task in the system
 * that has a description identical to the one in a task creation request.
 */
#define DUPLICATE_DESCRIPTION "duplicate description"
/* Message that is printed when there is already an activity in the system
 * that has a description identical to the one in an activity creation request.
 */
#define DUPLICATE_ACTIVITY "duplicate activity"
/* Message that is printed when there is already a user in the system
 * that has a name identical to the one in a user creation request.
 */
#define USER_ALREADY_EXISTS "user already exists"
/* Message that is printed when an operation requested by the client
 * contains an invalid description.
 * For instance, this error message is printed when the description of
 * an activity to be created contains lowercase ASCII characters
 * (UTF-8 validity and lowercase Unicode characters are not checked in this project).
 */
#define INVALID_DESCRIPTION "invalid description"
/* Message that is printed when a requested operation
 * contains an invalid duration.
 * This message is used in the command 't'.
 */
#define INVALID_DURATION "invalid duration"
/* Message that is printed when a requested operation
 * contains an invalid time span.
 * This message is used in the command 'n'.
 */
#define INVALID_TIME_SPAN "invalid time"
/* Message that is printed when an activity that is not in the activity TO DO
 * is moved to the activity TO DO.
 * (Requesting to move an activity that is in the activity TO DO to the activity TO DO
 * produces undefined behavior.)
 */
#define TASK_ALREADY_STARTED "task already started"

/* Name of the predefined activity TO DO. */
#define ACTIVITY_STRING_TODO "TO DO"
/* Name of the predefined activity IN PROGRESS. */
#define ACTIVITY_STRING_IN_PROGRESS "IN PROGRESS"
/* Name of the predefined activity DONE. */
#define ACTIVITY_STRING_DONE "DONE"

#endif /* !defined(KANBAN_MESSAGES_H) */
